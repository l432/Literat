Read Me for FCCS Ver. 1.5.0

1. How to execute FCCS program
   Please double-click FCCS1_5_0.exe in the "bin" folder.
2. How to use the application
   Please read the "Help" menu in the "Help" menu bar of FCCS application.
3. How to use the example data.
   The example data (*.nT or *.pT) are in the "Example" folder.
   