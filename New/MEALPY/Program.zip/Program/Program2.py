import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor

from sklearn.model_selection import train_test_split

data = pd.read_csv(r"E:\Desktop\jiedian_ABO3_1_qu.csv", encoding="gbk")
X=data.iloc[:,2:]
Y=data.iloc[:,1]
X = MinMaxScaler().fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=67)




def fitness_function(parameter):
    X1 = X_train
    y1 = y_train
    n = parameter[0]
    m = parameter[1]
    r = parameter[2]
    clf = RandomForestRegressor(n_estimators=int(n),max_depth=int(m),random_state=int(r))
    clf.fit(X1,y1)
    y_predict = clf.predict(X_test)
    r2 = metrics.r2_score(y_test, y_predict)
    # mae = mean_absolute_error(y_test, y_predict)
    # mse = mean_squared_error(y_test, y_predict)
    return r2  #,mae, mse

problem = {
    "fit_func": fitness_function,
    "lb": [1, ] * 3,
    "ub": [100, ] * 3,
    "minmax": "max",
    "log_to": None,
    "save_population": False,
}

from mealpy.swarm_based import ARO
model = ARO.OriginalARO(epoch=40, pop_size=30)
best_position, best_fitness = model.solve(problem)
fitness = model.history.list_global_best_fit
print(f"Best solution: {best_position}, Best fitness: {best_fitness}")
print(f" fitness: {fitness}")
# print("R2:",1-best_fitness)
# print("MAE:", mae)
# print("MSE:", mse)
print("RF n_estimators",best_position[0],"RF max_depth",best_position[1],"RF random_state",best_position[2])



import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = [u'SimHei']
plt.rcParams['axes.unicode_minus'] = False

plt.figure(figsize=(8,6))
m = range(1, 41, 1)

score1 = fitness
plt.plot(m,score1,color = 'red')
plt.xticks(size=15,fontweight='bold')
plt.yticks(size=15,fontweight='bold')
# plt.xticks(np.arange(0, 101, 10),size=15,fontweight='bold')
plt.xlabel('Iteration', fontsize=15,fontweight='bold')
plt.ylabel('Fitnes R2', fontsize=15,fontweight='bold')
plt.legend()
plt.savefig('ARO2.jpeg', dpi=500, bbox_inches='tight', pad_inches=0)
plt.show()



rf = RandomForestRegressor(n_estimators=int(best_position[0]), max_depth=int(best_position[1]),
                            random_state=int(best_position[2]))
rf.fit(X_train, y_train)
y_train_pred = rf.predict(X_train)
y_test_pred = rf.predict(X_test)

# 可视化训练集和测试集的真实值与预测值
fig, ax = plt.subplots(figsize=(8, 6))
plt.xlim(1.5,6.5)
plt.ylim(1.5,6.5)

plt.scatter(y_test, y_test_pred,c='#e30039',label='ARO-RFR')
plt.plot(y_test,y_test,c='black')
plt.plot(y_test,y_test, c='#fa4343',linewidth=50,alpha=0.5)
plt.xlabel(r'Predicted D(F/m)',fontsize=15)
plt.ylabel(r'true D(F/m)',fontsize=15)
plt.legend()
plt.savefig('ARO-RFR2.png')
plt.show()

