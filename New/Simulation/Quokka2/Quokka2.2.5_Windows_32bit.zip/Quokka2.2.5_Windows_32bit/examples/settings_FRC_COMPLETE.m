% Quokka v2.2.5 settings file
% (c) 2016 Andreas Fell

% FRC (front and rear contact) version
% This version sets the front conductive boundary to be of opposite majority carrier type to the bulk (front emitter)
% Higher flexibility of rear contact pattern relative to a single front contact
% supports different front / rear unit cell dimensions
% Rear junction cells can be modeled by switching the illumination to the rear

% Example of selective emitter LBSF p-type cell featuring 3 diffusions (2 front and 1 rear diffusion) below
% hexagonal rear contact pattern with pitch different to pitch of front line contacts
% besides the curve fitting functionality, all possible input parameters are listed here


version.design='FRC'; % don't change

%%%% unit cell geometry
geom.dimensions=2; % set to 1, 2 or 3
geom.Wz=180; % cell thickness [um] (including thickness of doped surface layers)
geom.Wxfront=750; % front unit cell size in x-direction [um]
geom.Wxrear=500; % rear unit cell size in x-direction [um]
% set above values equal to simulate a "standard" unit cell
% set to different values to let Quokka find the actual bigger unit cell
% note that the lowest common multiplier defines the actual unit cell size which may become very large and slow down the simulation
geom.Wy=500*sqrt(3); % unit cell size in y-direction [um]
geom.frontcont.shape='line'; % shape of front contact: 'circle', 'rectangle', 'line' or 'full'
geom.frontcont.wx=50; % contact half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle'
geom.frontcont.wy=50; % contact half width in y-direction for 'rectangle'
geom.rearcont.shape='rectangle'; % shape of rear contact: 'circle', 'rectangle', 'line' or 'full'
geom.rearcont.wx=50; % contact half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle'
geom.rearcont.wy=50; % contact half width in y-direction for 'rectangle'
geom.rearcont.position=[1 3]; % define positions of rear contacts (relative to single front contact):
                         % give vector of contact numbers representing the unit cell corners 1-4 e.g. [1 3]
                         % for lines contact numbers 2 and 4 are lines in x-direction
                         % for 2D only numbers 1 and 2 applicable
geom.meshquality=1; % determines solution accuracy and computation time, 1: coarse, 2: medium or 3: fine (or 'user' for expert settings)

% expert geometry settings, have effect only if geom.mesh_quality='user'
geom.dxmin=5; % minimum element size in x-direction [um]
geom.dymin=5; % minimum element size in y-direction [um]
geom.dzminfront=0.5; % minimum element size in z-direction at the front [um]
geom.dzminrear=0.5; % minimum element size in z-direction at the rear [um]
geom.scale=5; % this factor determines the mimum allowable ratio of minimum feature size to minimum element size
geom.inflation=2.5; % inflation factor, i.e. maximum allowable ratio of adjacent element sizes


                         
%%%% bulk material properties
bulk.type='p-type'; % doping type, 'p-type' or 'n-type'
bulk.rho=1; % resistivity [Ohm.cm]
bulk.taubfixed=1e20; % fixed lifetime [us] contribution to bulk recombination, set to very high value to disable
bulk.SRH.midgap.taup0=2500; % taup (holes) for midgap SRH [us] (Et-Ei=0), set to very high value to disable
bulk.SRH.midgap.taun0=2500; % taun (electrons) for midgap SRH [us] (Et-Ei=0), set to very high value to disable

% expert bulk settings
bulk.T=300; % temperature [K], leave at 300 K unless you are confident about what you are doing
bulk.nk='Green08_300K'; % optical properties: 'Green08_300K' or 'Green08_Nguyen14' (latter accounts for temp. dependence)
bulk.Auger='Richter2012'; % Auger model: 'Richter2012' (default), 'Altermatt2011', 'Kerr2002', 'Sinton1987' or 'off'
bulk.mobility='Klaassen'; % mobility model, 'Klaassen' (default), 'Arora' (PC1D) or 'fixed'
bulk.mun = 1100; % electron mobility [cm2/Vs] for 'fixed' mobility option
bulk.mup = 400; % hole mobility [cm2/Vs] for 'fixed' mobility option
bulk.nieff='default'; % 'default' (uses ni(300K)=9.65e9cm-3 and Schenk's doping dependent BGN) or 'fixed'
bulk.nieffvalue=9.65e9; % value for nieff for 'fixed' [cm-3]
bulk.nk='Green08_300K'; % optical properties of silicon, 'Green08_300K' or 'Green08_Nguyen14' (default)
bulk.Brad=4.73e-15; % radiative recombination coefficent [cm3/s], default: 4.73e-15 (Trupke et al. 2003)
bulk.SRH.BO.Nt=0; % Oxygen concentration for BO complex SRH recombination in p-type [cm-3]
bulk.SRH.BO.m=2; % processing dependent parameter between 2 and 4
% define multiple SRH defects by cell indexing, example for Fe:
bulk.SRH.custom{1}.Nt=0; % defect density [cm-3], set to zero to disable defect
bulk.SRH.custom{1}.Et_Ei=-0.18; % defect level [eV], relative to intrinsic energy (Et-Ei)
bulk.SRH.custom{1}.sigman=1.3e-14; % electron capture cross section [cm2]
bulk.SRH.custom{1}.sigmap=1.3e-14; % hole capture cross section [cm2]



%%%% Boundary properties, conductive (e.g. surface diffusion) and non-conductive (e.g. undiffused passivated surface)
% Only one non-conductive boundary per front and rear surface can be defined, which is applied to wherever no other conductive boundary is defined
% 'cont' / 'noncont' denotes the contacted / non-contacted area
% For 1D, 'cont' i.e. contacted area properties will be used
% Several boundaries can be defined by cell indexing, note that a higher index overrides lower index boundaries if their shapes intersect
% Only applicable inputs must be given, e.g. contacted properties don't need to be defined if no area of the boundary is contacted

% Properties of all boundaries:
% .location: 'front' or 'rear'
% .cont.rec: recombination model of contacted area; 'S', 'J0' or 'expr'
% .noncont.rec: same as above of non-contacted area
% .cont.S: effective SRV [cm/s] of contacted area if if cont.rec='S'
% .noncont.S: same as above of non-contacted area
% .cont.J0: ideal (n=1) recombination current prefactor [A/cm2] of contacted area if cont.rec='J0'
% .noncont.J0: same as above of non-contacted area
% .cont.expr: analytical expression for recombination current density [A/cm2], example for n=3 nonideal recombination: '1e-8*(dn*const.N/const.nieff^2)^(1/3)'
% .noncont.expr: same as above of non-contacted area
% .cont.rc: contact resistivity [Ohm.cm2] of contacted area

% Additional applicable properties for conductive boundaries only
% .Rsheet: sheet resistance [Ohm/sq]
% .shape: 'none' (to disable), 'full', 'line', 'rectangle', 'circle' or 'contact' (the latter applies the same shape and dimensions as the contact on the respective side)
% .wx: half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle' [um]
% .wy: half width in y-direction for 'rectangle' [um]

% optional expert boundary properties
% .cont.J02: nonideal (n=2) recombination current prefactor [A/cm2] of contacted area
% .noncont.J02: same as above of non-contacted area
% .jctdepth: junction depth [um], used for determination of collection current within the boundary
% additionally the area average of the junction depths is applied for reduction of the solution domain width in z-direction
% .colleff: collection efficiency [], used for determination of collection current within the boundary

% undiffused rear side properties:
bound.nonconduct{1}.location='rear';
bound.nonconduct{1}.noncont.rec='S';
bound.nonconduct{1}.noncont.S=20;

% full area front emitter diffusion (automatically set to n-type):
bound.conduct{1}.location='front'; 
bound.conduct{1}.Rsheet=150;
bound.conduct{1}.noncont.rec='J0';
bound.conduct{1}.noncont.J0=30e-15;
bound.conduct{1}.shape='full';
bound.conduct{1}.jctdepth=0.5;
bound.conduct{1}.colleff=0.99;

% selective emitter diffusion which is wider than the contact and thus partially contacted:
bound.conduct{2}.location='front';
bound.conduct{2}.Rsheet=30;
bound.conduct{2}.cont.rec='J0';
bound.conduct{2}.cont.J0=400e-15;
bound.conduct{2}.cont.rc=1e-3;
bound.conduct{2}.noncont.rec='J0';
bound.conduct{2}.noncont.J0=200e-15;
bound.conduct{2}.shape='line';
bound.conduct{2}.wx=75;
bound.conduct{2}.jctdepth=2;
bound.conduct{2}.colleff=0.90;
bound.conduct{2}.cont.J02=5e-8;

% rear side LBSF diffusion which is aligned to the contact (automatically set to p-type)
bound.conduct{3}.location='rear';
bound.conduct{3}.Rsheet=20;
bound.conduct{3}.cont.rec='J0';
bound.conduct{3}.cont.J0=400e-15;
bound.conduct{3}.cont.rc=1e-3;
bound.conduct{3}.shape='contact';
bound.conduct{3}.jctdepth=10;
bound.conduct{3}.colleff=0.60;




%%%% generation settings
generation.type='1D_model'; % how generation is defined:  '1D_model', 'Jgen_surface', 'Jgen_uniform', 'ext_file', 'customdata' or 'off'
generation.intensity=100; % incident light intensity [mW/cm2] (default: 100), not applicable for 1D_model, does NOT influence the actual generation
generation.Jgen=40; % generation current [mA/cm2]
generation.Jgen_correction=0; % 1 scales generation profile to match generation.Jgen; useful to correct for numerical errors if Jgen is known
generation.ext_file='PVL_QuokkaGenFile.txt'; % generation rate file; first column depth [um], second column G [cm-3s-1]
generation.profile_type='standard'; % use 'standard' or 'cumulative' (PC1D) generation profile, latter gives more accuracy in total generation
generation.customdata=[]; % generation rate vector data: [z1, z2, ... zn; G1, G2, ... Gn] with z = distance to illuminated surface [um] and G = generation rate [cm-3] 
generation.suns=1; % scales the generation
generation.illum_side='front'; % illuminated side, 'front' or 'rear'
generation.shading_width=50; % half width in x-direction [um] for shading of fingers, set to zero for no shading
% below settings are for '1D_model'
% calculates the current generation within the junction depth like PC1D
% models the first path through the cell properly, generation from all subsequent passes is uniformly re-distributed
generation.transmission='ext_file'; % how front surface transmission is defined: 'fixed', 'ext_file' or 'custom' (set generation.transmission_custom=[lambda1 lambda2 ... lambdan; T1 T2 ... Tn] with lambda [nm] and transmission T [])
generation.transmission_value=0.66; % transmission value [] for 'fixed' transmission
generation.transmission_filename='PVL_QuokkaRATFile.txt'; % front transmission file ; first column wavelength [nm], second column T [0..1]
generation.Z='limit_Green02'; % optical pathlength enhancement: 'fixed', 'ext_file', 'custom', 'param', 'limit_4n2' or 'limit_Green02'
generation.Z_filename='PVL_ZFile.txt'; % Z file; first column wavelength [nm] second column Z
generation.Z_value=6; % constant optical pathlength enhancement for generation.Z='fixed'
generation.Z0=10; % Z0 of McIntosh15 Z-parameterization
generation.Zinf=1; % Zinf of McIntosh15 Z-parameterization
generation.Zp=2; % Zp of McIntosh15 Z-parameterization
generation.spectrum='AM1.5g'; % incident spectrum, 'AM1.5g', 'monochromatic' or 'custom' (set generation.spectrum_custom=[lambda1 lambda2 ... lambdan; I1 I2 ... In] with lambda [nm] and I [W/m2/nm])
generation.facet_angle=54.7; % [degrees] should be the same as assumed when calculating Z and RAT values, set to 0 for planar surface
% below needs to be set if generation.spectrum='monochromatic'
generation.monochromatic.wavelength=1200; % wavelength [nm] for monochromatic spectrum setting
generation.monochromatic.flux=1e15; % monochromatic photon flux [1/cm2/s]



%%%% external circuit settings
circuit.Rseries=0.1; % external series resistance [Ohm.cm2]
circuit.Rshunt=1e5; % external shunt resistance [Ohm.cm2]
circuit.terminal='Vuc'; % 'Vuc', 'Vterm', 'Jterm', 'OC', 'MPP', 'Jsc' (not short circuit!), 'light_IV_auto', 'IV_curve', 'QE_curve', 'sunsVoc_curve' or 'Rs_curve'
circuit.Vuc.value=0.5; % unit vell voltage [V] for 'Vuc'
circuit.Vterm.value=0.5; % terminal voltage [V] for 'Vterm'
circuit.Jterm.value=-30; % terminal current density [mA/cm2] for 'Jterm'
circuit.IV.V_values=[0.3:0.05:0.75]; % vector of voltage values [V] for 'IV_curve'
circuit.IV.mode='Vterm'; % 'Vuc' (faster) or 'Vterm' defines the meaning of the voltage values for 'IV_curve'
circuit.QE.wavelength_values=[300:25:1125]; % vector of wavelength values [nm] for 'QE_curve'

% expert external circuit settings
circuit.DJ0=0; %  J0 [A/cm2] of external parallel diode in forward bias
circuit.Dn=2; % ideality factor of external parallel diode in forward bias
circuit.Voc_guess=0.67; % guess of Voc [V] for quicker convergence, can be a vector / matrix for sweeps
circuit.IV_accuracy=1; % use values >1 to increase the number of IV points calculated for 'light_IV_auto'; default: 1 (5 recommended for 'Rs_curve')



%%%% sweep
% sweep of one or two independent parameters
% additional parameters can be swept dependently:
% e.g. sweep_1{1}='size_x', sweep_1{2}='size_y' and values_1{1}= ...
sweep.enable=1; % 0 or 1 to disable / enable
sweep.param_1{1}='bulk.nk'; % parameter name in quotation marks, e.g. sweep_1='bulk.rho'
sweep.param_2{1}='bound.conduct{3}.cont.J0'; % parameter name in quotation marks, e.g. sweep2='bulk.rho'
sweep.values_1{1}={'Green08_300K','Green08_Nguyen14'}; % [] for no sweep or vector, e.g. [1 4 6]
sweep.values_2{1}=[]; % [] for no sweep or vector, e.g. [1 4 6]




%%%% luminescence settings
% external files must cover the wavelength range from 800nm - 1400nm the first column and respective data in the next column(s)
lumi.enable=1; % 0 or 1 to disable / enable
lumi.scale=2.33e-8; % scales simulated luminiscence signal [photons/cm2/s] to match experimental measurement units, e.g. [counts/s]
lumi.filter='ext_file'; % 'none' for no filter or 'ext_file'
lumi.filter_filename='PL_SP1025nm.xls'; % filter transmission file; first columns wavelength [nm], second column transmission [0..1]
lumi.sensor_EQE='silicon'; % external quantum efficiency of sensor: 'silicon' (thickness is used for calculation of EQE), 'unity' (EQE=1) or 'ext_file'
lumi.sensor_EQE_filename='filename.xls'; % sensor EQE file; first column wavelength [nm], second column EQE [0..1]
lumi.sensor_thickness=55.7; % thickness of CCD sensor [um], for silicon sensor only
lumi.detection_side='illuminated'; % Side which is treated as the front for luminescence modeling, relative to illuminated side: 'illuminated' or 'opposite'
lumi.normalise_signal=0; % Normalise signal to peak intensity, 0 or 1 to disable / enable
% Define escape function as per the models below
% 1: Schick et al, Apply. Phys. A, vol. 54. pp. 109-114     [Planar]
% 2: Rudiger et al, Proc. 22nd EUPVSEC, 2007, pp. 386-389   [Textured]
% 3: Schinke et al, IEEE JPV, Vol 3., No. 3, 2013           [general]
% 4: Padilla et al, SolMat, 2014, Vol 120, p. 363-375       [geometrical blurring model for front and rear lambertian surfaces]
lumi.emission_function = 3;
lumi.internal_refl='default'; % internal reflectivity (not applicable for Rudiger model): 'default' for Si - air interface or 'ext_file' 
lumi.internal_refl_filename='filename.xls'; % internal reflectivity file; first columns wavelength [nm], second column front reflectivity [0..1], third column rear reflectivity [0..1]
lumi.general.facet_angle = 54.7; % Facet angle based on front surface texture geometry. [Degrees]
lumi.general.lambertian_factor = 0.5; % Lambertian factor of the rear surface, between 0 and 1, 0: fully specular, 1: fully diffuse
% If using the Schinke Model (3), the following inputs define the behaviour of
% internal reflections within the sample, and are generally determined
% empirically or via ray-tracing models. Default values can be used as
% a general approximation for a textured front and planar rear surface
% More details in Schinke et al, IEEE JPV, Vol 3., No. 3, 2013
lumi.general.refRear = 0.60; % rear reflectivity [], default 0.60
lumi.general.refFrontS = 0.62; % first front reflectivity [], default 0.62
lumi.general.refFrontN = 0.93; % n-th front reflectivity [], default 0.93
% input for Padilla model (4):
lumi.geometrical.number_reflections=0; % number of internal reflection to model
% optional input for modeled wavelength range
lumi.wavelength_start=900; % [nm]
lumi.wavelength_end=1200; % [nm]


%%%% optimizer settings for data fitting or performance optimization
% when vector data are given optimization is performed sequentially for each value (all vectors must have the same length or be a scalar to be assumed constant)
optim.enable=0; % 0: disable, 1: normal mode, 2: curve fitting mode
optim.maxiter=20; % maximum number of iterations
optim.accuracy=1; % influences tolerances of optimizer (default=1, recommended 0.1 ... 10); higher values increase accuracy of results, but increase required number of iterations and the risk of bad / no convergence
optim.param{1}='bound.conduct{2}.cont.J0'; % parameter name to optimize (as given in settings file)
optim.start{1}=10000e-15; % (vector of) start value(s) of parameter (units as given in settings file)
optim.lb{1}=100e-15; % (vector of) lower bound(s)
optim.ub{1}=300000e-15; % (vector of) upper bound(s)
% possible to define more parameters to optimize by cell index {2}, {3} ...

% goal settings for normal mode
optim.goal{1}='results.taueff'; % name of scalar output to achieve, can be any scalar of the results structure
optim.value{1}=1e3; % (vector of) value(s) of goal to achieve (units as given in results file) or 'min' / 'max' (for a single goal cell only)
% possible to define more goals by cell index {2}, {3} ...

% goal settings for curve fitting mode (does not support sequential optimization)
optim.goalx='results.navg'; % must be a vector result produced by a single simulation run
optim.goaly='results.taueff'; % must be a vector result produced by a single simulation run with the same length as optim.goalx
optim.xyfile='QSSPC_lifetime_curve.xls'; % file with two columns for x- and y-goal values, in units of optim.goalx and optim.goaly output vectors

% following settings provide possibility to override parameter values, useful for sequential optimization and parameter(s) dependent on the parameter(s) to optimize
optim.override.param{1}='bound.conduct{3}.cont.J0'; % parameter name to override
optim.override.value{1}='bound.conduct{2}.cont.J0'; % (vector of) value(s) or analytic expression in quotation marks containing name(s) of parameter(s) to optimize
% possible to define more overrides by cell index {2}, {3} ...
% to disable: optim.override.value{1}=[]
