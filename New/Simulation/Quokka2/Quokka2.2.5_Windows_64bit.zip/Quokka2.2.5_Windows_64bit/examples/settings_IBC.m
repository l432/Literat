% Quokka v2.2 settings file
% (c) 2014 Andreas Fell

% IBC (interdigitated back contact) version
% The metal finger for the opposite polarity to the bulk (emitter) is always centred on the left hand side, and the other metal finger on the right hand side
% e.g. for n-type cell: p-finger centred on the left (x=0), n-finger centred on the right (x=Wx), the same applies for conductive boundaries
% allows for several contacts in x-direction with a defined pitch
% in y-direction the variation is limited to the left hand side contact pitch can being equal, half or double the right hand side contact pitch
% The conductive boundaries are aligned to the contacts unless their x-dimension is bigger than the contact pitch, in which case they are centred on the respective solution domain corner (x,y=0,0 or x,y=Wx,Wy) 
% Note that the IBC version of Quokka does not support contact to a non-conductive boundary


version.design='IBC'; % don't change

%%%% unit cell geometry
geom.dimensions=3; % set to 2 or 3
geom.Wz=180; % cell thickness [um]
geom.Wx=375; % unit cell size in x-direction [um]
geom.Wy=75; % unit cell size in y-direction [um]
geom.rightcont.shape='rectangle'; % shape of right hand side (base) contact: 'circle', 'rectangle', or 'line'
geom.rightcont.wx=7; % contact half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle'
geom.rightcont.wy=7; % contact half width in y-direction for 'rectangle'
geom.rightcont.pitchx=75; % full pitch of contacts in x-direction
geom.rightcont.numberx=2; % number of contacts in x-direction (can be fractional 0.5, 1, 1.5 ...)
geom.rightcont.w_metal=130; % metal finger half width for generation profile splitting and shading for rear illumination
geom.leftcont.shape='rectangle'; % shape of left hand side (emitter) contact: 'circle', 'rectangle', or 'line'
geom.leftcont.wx=7; % contact half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle'
geom.leftcont.wy=7; % contact half width in y-direction for 'rectangle'
geom.leftcont.pitchx=75; % full pitch of contacts in x-direction
geom.leftcont.numberx=3; % number of contacts in x-direction (can be fractional 0.5, 1, 1.5 ...)
geom.leftcont.w_metal=210; % metal finger half width for generation profile splitting and shading for rear illumination
geom.leftcont.y_position='aligned'; % position of left hand side (emitter) contact(s) relative to opposite contact(s) in y-direction: 'aligned', 'opposite', 'double', 'half'
geom.meshquality=1; % determines solution accuracy and computation time, 1: coarse, 2: medium or 3: fine (or 'user' for expert settings)

% expert geometry settings, have effect only if geom.mesh_quality='user'
geom.dxmin=5; % minimum element size in x-direction [um]
geom.dymin=5; % minimum element size in y-direction [um]
geom.dzminfront=0.5; % minimum element size in z-direction at the front [um]
geom.dzminrear=0.5; % minimum element size in z-direction at the rear [um]
geom.scale=5; % this factor determines the mimum allowable ratio of minimum feature size to minimum element size
geom.inflation=2.5; % inflation factor, i.e. maximum allowable ratio of adjacent element sizes
           


%%%% bulk material properties
bulk.type='n-type'; % doping type, 'p-type' or 'n-type'
bulk.rho=0.8; % resistivity [Ohm.cm]
bulk.taubfixed=1e20; % fixed lifetime [us] contribution to bulk recombination, set to very high value to disable
bulk.SRH.midgap.taup0=2500; % taup (holes) for midgap SRH [us] (Et-Ei=0), set to very high value to disable
bulk.SRH.midgap.taun0=2500; % taun (electrons) for midgap SRH [us] (Et-Ei=0), set to very high value to disable

% expert bulk settings
bulk.T=300; % temperature [K], leave at 300 K unless you are confident about what you are doing
bulk.Auger='Richter2012'; % Auger model: 'Richter2012' (default), 'Altermatt2011', 'Kerr2002', 'Sinton1987' or 'off'
bulk.mobility='Klaassen'; % mobility model, 'Klaassen' (default) or 'Arora' (PC1D)
bulk.nieff='default'; % 'default' (uses ni(300K)=9.65e9cm-3 and Schenk's doping dependent BGN) or 'fixed'
bulk.nieffvalue=9.65e9; % value for nieff for 'fixed' [cm-3]
bulk.Brad=4.73e-15; % radiative recombination coefficent [cm3/s], default: 4.73e-15 (Trupke et al. 2003)
bulk.SRH.BO.Nt=0; % Oxygen concentration for BO complex SRH recombination in p-type [cm-3]
bulk.SRH.BO.m=2; % processing dependent parameter between 2 and 4
% define multiple SRH defects by cell indexing, example for Fe:
bulk.SRH.custom{1}.Nt=0; % defect density [cm-3], set to zero to disable defect
bulk.SRH.custom{1}.Et_Ei=-0.18; % defect level [eV], relative to intrinsic energy (Et-Ei)
bulk.SRH.custom{1}.sigman=1.3e-14; % electron capture cross section [cm2]
bulk.SRH.custom{1}.sigmap=1.3e-14; % hole capture cross section [cm2]




%%%% Boundary properties, conductive (e.g. surface diffusion) and non-conductive (e.g. undiffused passivated surface)
% In this IBC version exactly two conductive boundies at the rear have to be defined (left and right rear side) and optionally one at the front
% Only one non-conductive boundary per front and rear surface can be defined, which is applied to wherever no other conductive boundary is defined
% 'cont' / 'noncont' denotes the contacted / non-contacted area
% Several boundaries can be defined by cell indexing, note that a higher index overrides lower index boundaries if their shapes intersect
% Only applicable inputs must be given, e.g. contacted properties don't need to be defined if no area of the boundary is contacted

% Properties of all boundaries:
% .location: 'front' or 'rear' (latter one only for non-conductive boundary)
% .cont.rec: recombination model of contacted area; 'S', 'J0' or 'expr'
% .noncont.rec: same as above of non-contacted area
% .cont.S: effective SRV [cm/s] of contacted area if if cont.rec='S'
% .noncont.S: same as above of non-contacted area
% .cont.J0: ideal (n=1) recombination current prefactor [A/cm2] of contacted area if cont.rec='J0'
% .noncont.J0: same as above of non-contacted area
% .cont.expr: analytical expression for recombination current density [A/cm2], example for n=3 nonideal recombination: '1e-8*(dn*const.N/const.nieff^2)^(1/3)'
% .noncont.expr: same as above of non-contacted area
% .cont.rc: contact resistivity [Ohm.cm2] of contacted area

% Additional applicable properties for conductive boundaries only
% .location: 'left', 'right'
% .type: type of majority carriers / surface doping type: 'p-type' or 'n-type', applicable for front side only
% .Rsheet: sheet resistance [Ohm/sq]
% .shape: 'none' (to disable), 'full', 'line', 'rectangle', 'circle' or 'contact' (the latter applies the same shape and dimensions as the contact on the respective side)
% In the IBC version a front conductive boundary is always 'full'
% .wx: half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle' [um]
% .wy: half width in y-direction for 'rectangle' [um]

% optional expert boundary properties
% .cont.J02: nonideal (n=2) recombination current prefactor [A/cm2] of contacted area
% .noncont.J02: same as above of non-contacted area
% .jctdepth: junction depth [um], used for determination of collection current within the boundary
% additionally the area average of the junction depths is applied for reduction of the solution domain width in z-direction
% .colleff: collection efficiency [], used for determination of collection current within the boundary

% undiffused rear side properties:
bound.nonconduct{1}.location='rear';
bound.nonconduct{1}.noncont.rec='S';
bound.nonconduct{1}.noncont.S=20;

% left conductive boundary (emitter) with a lineshape (automatically set to p-type for n-type bulk):
bound.conduct{1}.location='left'; 
bound.conduct{1}.Rsheet=150;
bound.conduct{1}.cont.rec='J0';
bound.conduct{1}.cont.J0=300e-15;
bound.conduct{1}.cont.rc=1e-3;
bound.conduct{1}.noncont.rec='J0';
bound.conduct{1}.noncont.J0=100e-15;
bound.conduct{1}.shape='line';
bound.conduct{1}.wx=230;
bound.conduct{1}.jctdepth=0.5;
bound.conduct{1}.colleff=0.99;
bound.conduct{1}.cont.J02=5e-8;

% right localized conductive boundary (LBSF) which is aligned to the contact (automatically set to n-type for n-type bulk):
bound.conduct{2}.location='right';
bound.conduct{2}.Rsheet=30;
bound.conduct{2}.cont.rec='J0';
bound.conduct{2}.cont.J0=200e-15;
bound.conduct{2}.cont.rc=1e-3;
bound.conduct{2}.noncont.rec='J0';
bound.conduct{2}.noncont.J0=200e-15;
bound.conduct{2}.wx=15;
bound.conduct{2}.shape='circle';
bound.conduct{2}.jctdepth=1;
bound.conduct{2}.colleff=0.90;

% front conductive boundary (FSF):
bound.conduct{3}.location='front';
bound.conduct{3}.type='n-type';
bound.conduct{3}.Rsheet=200;
bound.conduct{3}.noncont.rec='J0';
bound.conduct{3}.noncont.J0=15e-15;
bound.conduct{3}.jctdepth=0.5;
bound.conduct{3}.colleff=0.99;



%%%% generation settings
generation.type='ext_file'; % how generation is defined: '1D_model', 'Jgen_surface', 'Jgen_uniform', 'monochromatic', 'ext_file', 'customdata' or 'off'
% The IBC version additionally allows 'ext_file_split' and 'customdata_split' to use different generation profiles for different rear side regions
% The subfields of generation to be defined are (e.g. generation.gap_metal.ext_file='PVL_GenProf_gap.xls'):
% .gap_metal: non-contacted non-conductive boundary covered by metal finger
% .gap_nometal: non-contacted non-conductive boundary not covered by metal finger
% .left_metal: non-contacted left conductive boundary covered by metal finger
% .left_nometal: non-contacted left conductive boundary not covered by metal finger
% .left_contact: contacted left conductive boundary
% .right_metal: non-contacted right conductive boundary covered by metal finger
% .right_nometal: non-contacted right conductive boundary not covered by metal finger
% .right_contact: contacted right conductive boundary
generation.intensity=100; % incident light intensity [mW/cm2] (default: 100), not applicable for 1D_model, does NOT influence the actual generation
generation.Jgen=40; % generation current [mA/cm2] (will be applied to the illuminated side surface or uniformly in the bulk)
generation.ext_file='PVL_QuokkaGenFile.txt'; % generation rate file; first column depth [um], second column G [cm-3s-1]
generation.customdata=[]; % generation rate vector data: [z1, z2, ... zn; G1, G2, ... Gn] with z = distance to illuminated surface [um] and G = generation rate [cm-3s-1] 
generation.suns=1; % scales the generation
generation.illum_side='front'; % illuminated side, 'front' or 'rear'
generation.shading_width=50; % half width in x-direction [um] for shading of fingers, set to zero for no shading
% below settings are for '1D_model'
% calculates the current generation within the junction depth like PC1D
% models the first path through the cell properly, generation from all subsequent passes is uniformly re-distributed
generation.transmission='ext_file'; % how front surface transmission is defined: 'fixed', 'ext_file' or 'custom' (set generation.transmission_custom=[lambda1 lambda2 ... lambdan; T1 T2 ... Tn] with lambda [nm] and transmission T [])
generation.transmission_value=0.66; % transmission value [] for 'fixed' transmission
generation.transmission_filename='PVL_QuokkaRATFile.txt'; % front transmission file ; first column wavelength [nm], second column T [0..1]
generation.Z='ext_file'; % optical pathlength enhancement: value, 'fixed', 'ext_file' or 'custom'
generation.Z_filename='PVL_ZFile.txt'; % Z file; first column wavelength [nm] second column Z
generation.Z_value=6; % constant optical pathlength enhancement for generation.Z='fixed'
generation.spectrum='AM1.5g'; % incident spectrum, 'AM1.5g', 'monochromatic' or 'custom' (set generation.spectrum_custom=[lambda1 lambda2 ... lambdan; I1 I2 ... In] with lambda [nm] and I [W/m2/nm])
generation.facet_angle=54.7; % [degrees] should be the same as assumed when calculating Z and RAT values, set to 0 for planar surface
% below needs to be set if generation.spectrum='monochromatic'
generation.monochromatic.wavelength=1200; % wavelength [nm] for monochromatic spectrum setting
generation.monochromatic.flux=1e15; % monochromatic photon flux [1/cm2/s]

% split profile example: 
generation.gap_metal.ext_file='PVL_GenProfile.xlsx';
generation.gap_nometal.ext_file='PVL_GenProfile.xlsx';
generation.left_metal.ext_file='PVL_GenProfile.xlsx';
generation.left_nometal.ext_file='PVL_GenProfile.xlsx';
generation.left_contact.ext_file='PVL_GenProfile.xlsx';
generation.right_metal.ext_file='PVL_GenProfile.xlsx';
generation.right_nometal.ext_file='PVL_GenProfile.xlsx';
generation.right_contact.ext_file='PVL_GenProfile.xlsx';


%%%% external circuit settings
circuit.Rseries=0.1; % external series resistance [Ohm.cm2]
circuit.Rshunt=1e5; % external shunt resistance [Ohm.cm2]
circuit.terminal='MPP'; % 'Vuc', 'Vterm', 'Jterm', 'OC', 'MPP', 'Jsc' (not short circuit!), 'light_IV_auto', 'IV_curve', 'QE_curve', 'sunsVoc_curve' or 'Rs_curve'
circuit.Vuc.value=0.5; % unit vell voltage [V] for 'Vuc'
circuit.Vterm.value=0.5; % terminal voltage [V] for 'Vterm'
circuit.Jterm.value=-30; % terminal current density [mA/cm2] for 'Jterm'
circuit.IV.V_values=[0.3:0.05:0.75]; % vector of voltage values [V] for 'IV_curve'
circuit.IV.mode='Vterm'; % 'Vuc' (faster) or 'Vterm', defines the meaning of the voltage values for 'IV_curve'
circuit.QE.wavelength_values=[300:25:1125]; % vector of wavelength values [nm] for 'QE_curve'

% expert external circuit settings
circuit.DJ0=0; %  J0 [A/cm2] of external parallel diode in forward bias
circuit.Dn=2; % ideality factor of external parallel diode in forward bias
circuit.Voc_guess=0.67; % guess of Voc [V] for quicker convergence, can be a vector / matrix for sweeps
circuit.IV_accuracy=1; % use values >1 to increase the number of IV points calculated for 'light_IV_auto'; default: 1 (5 recommended for 'Rs_curve')



%%%% sweep
% sweep of one or two independent parameters
% additional parameters can be swept dependently:
% e.g. sweep_1{1}='size_x', sweep_1{2}='size_y' and values_1{1}= ...
sweep.enable=0; % 0 or 1 to disable / enable
sweep.param_1{1}='optics.suns'; % parameter name in quotation marks, e.g. sweep_1='bulk.rho'
sweep.param_2{1}='bulk.rho'; % parameter name in quotation marks, e.g. sweep2='bulk.rho'
sweep.values_1{1}=[]; % [] for no sweep or vector, e.g. [1 4 6]
sweep.values_2{1}=[]; % [] for no sweep or vector, e.g. [1 4 6]



% for optimizer and luminescence settings see settings_FRC_COMPLETE.m