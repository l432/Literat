% Quokka v2.2 settings file
% (c) 2014 Andreas Fell

% FRC (front and rear contact) version

% Example of full area BSF cell in 2D below, restricted to basic settings.
% Enable parameter sweep to sweep oxygen concentration
% For a complete listing of available settings see settings_FRC_COMPLETE.m

version.design='FRC'; % don't change

%%%% unit cell geometry
geom.dimensions=2; % set to 1, 2 or 3
geom.Wz=180; % cell thickness [um] (including thickness of doped surface layers)
geom.Wxfront=750; % front unit cell size in x-direction [um]
geom.Wxrear=750; % rear unit cell size in x-direction [um]
% set above values equal to simulate a "standard" unit cell
% set to different values to let Quokka find the actual bigger unit cell
% note that the lowest common multiplier defines the actual unit cell size which may become very large and slow down the simulation

geom.frontcont.shape='line'; % shape of front contact: 'circle', 'rectangle', 'line' or 'full'
geom.frontcont.wx=50; % contact half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle'
geom.rearcont.shape='full'; % shape of rear contact: 'circle', 'rectangle', 'line' or 'full'
geom.meshquality=1; % determines solution accuracy and computation time, 1: coarse, 2: medium or 3: fine (or 'user' for expert settings)


                         
%%%% bulk material properties
bulk.type='p-type'; % doping type, 'p-type' or 'n-type'
bulk.rho=1; % resistivity [Ohm.cm]
bulk.taubfixed=1e20; % fixed lifetime [us] contribution to bulk recombination, set to very high value to disable
bulk.SRH.midgap.taup0=2500; % taup (holes) for midgap SRH [us] (Et-Ei=0), set to very high value to disable
bulk.SRH.midgap.taun0=2500; % taun (electrons) for midgap SRH [us] (Et-Ei=0), set to very high value to disable

% expert bulk settings
bulk.SRH.BO.Nt=1e17; % Oxygen concentration for BO complex SRH recombination in p-type [cm-3]
bulk.SRH.BO.m=2; % processing dependent parameter between 2 and 4


%%%% Boundary properties, conductive (e.g. surface diffusion) and non-conductive (e.g. undiffused passivated surface)
% Only one non-conductive boundary per front and rear surface can be defined, which is applied to wherever no other conductive boundary is defined
% 'cont' / 'noncont' denotes the contacted / non-contacted area
% For 1D, 'cont' i.e. contacted area properties will be used
% Several boundaries can be defined by cell indexing, note that a higher index overrides lower index boundaries if their shapes intersect
% Only applicable inputs must be given, e.g. contacted properties don't need to be defined if no area of the boundary is contacted

% Properties of all boundaries:
% .location: 'front' or 'rear'
% .cont.rec: recombination model of contacted area; 'S', 'J0' or 'expr'
% .noncont.rec: same as above of non-contacted area
% .cont.S: effective SRV [cm/s] of contacted area if if cont.rec='S'
% .noncont.S: same as above of non-contacted area
% .cont.J0: ideal (n=1) recombination current prefactor [A/cm2] of contacted area if cont.rec='J0'
% .noncont.J0: same as above of non-contacted area
% .cont.expr: analytical expression for recombination current density [A/cm2], example for n=3 nonideal recombination: '1e-8*(dn*const.N/const.nieff^2)^(1/3)'
% .noncont.expr: same as above of non-contacted area
% .cont.rc: contact resistivity [Ohm.cm2] of contacted area

% Additional applicable properties for conductive boundaries only
% .Rsheet: sheet resistance [Ohm/sq]
% .shape: 'none' (to disable), 'full', 'line', 'rectangle', 'circle' or 'contact' (the latter applies the same shape and dimensions as the contact on the respective side)
% .wx: half width in x-direction for 'rectangle', half width for 'line' or radius for 'circle' [um]
% .wy: half width in y-direction for 'rectangle' [um]

% optional expert boundary properties
% .cont.J02: nonideal (n=2) recombination current prefactor [A/cm2] of contacted area
% .noncont.J02: same as above of non-contacted area
% .jctdepth: junction depth [um], used for determination of collection current within the boundary
% additionally the area average of the junction depths is applied for reduction of the solution domain width in z-direction
% .colleff: collection efficiency [], used for determination of collection current within the boundary

% full area front emitter diffusion (automatically set to n-type):
bound.conduct{1}.location='front'; 
bound.conduct{1}.Rsheet=80;
bound.conduct{1}.noncont.rec='J0';
bound.conduct{1}.noncont.J0=100e-15;
bound.conduct{1}.cont.rec='J0';
bound.conduct{1}.cont.J0=1000e-15;
bound.conduct{1}.cont.rc=1e-3;
bound.conduct{1}.shape='full';
bound.conduct{1}.jctdepth=0.5;
bound.conduct{1}.colleff=0.90;

% full area fully contacted rear BSF (automatically set to p-type):
bound.conduct{2}.location='rear';
bound.conduct{2}.Rsheet=30;
bound.conduct{2}.cont.rec='J0';
bound.conduct{2}.cont.J0=400e-15;
bound.conduct{2}.cont.rc=1e-3;
bound.conduct{2}.shape='full';



%%%% generation settings
generation.type='1D_model'; % how generation is defined:  '1D_model', 'Jgen_surface', 'Jgen_uniform', 'ext_file', 'customdata' or 'off'
generation.intensity=100; % incident light intensity [mW/cm2] (default: 100), not applicable for 1D_model, does NOT influence the actual generation
generation.Jgen=40; % generation current [mA/cm2] (will be applied to the illuminated side surface or uniformly in the bulk)
generation.ext_file='PVL_QuokkaGenFile.txt'; % generation rate file; first column depth [um], second column G [cm-3s-1]
generation.customdata=[]; % generation rate vector data: [z1, z2, ... zn; G1, G2, ... Gn] with z = distance to illuminated surface [um] and G = generation rate [cm-3] 
generation.suns=1; % scales the generation
generation.illum_side='front'; % illuminated side, 'front' or 'rear'
generation.shading_width=50; % half width in x-direction [um] for shading of fingers, set to zero for no shading
% below settings are for '1D_model'
% calculates the current generation within the junction depth like PC1D
% models the first path through the cell properly, generation from all subsequent passes is uniformly re-distributed
generation.transmission='ext_file'; % how front surface transmission is defined: 'fixed', 'ext_file' or 'custom' (set generation.transmission_custom=[lambda1 lambda2 ... lambdan; T1 T2 ... Tn] with lambda [nm] and transmission T [])
generation.transmission_value=0.66; % transmission value [] for 'fixed' transmission
generation.transmission_filename='PVL_QuokkaRATFile.txt'; % front transmission file ; first column wavelength [nm], second column T [0..1]
generation.Z='ext_file'; % optical pathlength enhancement: value, 'fixed', 'ext_file' or 'custom'
generation.Z_filename='PVL_ZFile.txt'; % Z file; first column wavelength [nm] second column Z
generation.Z_value=6; % constant optical pathlength enhancement for generation.Z='fixed'
generation.spectrum='AM1.5g'; % incident spectrum, 'AM1.5g', 'monochromatic' or 'custom' (set generation.spectrum_custom=[lambda1 lambda2 ... lambdan; I1 I2 ... In] with lambda [nm] and I [W/m2/nm])
generation.facet_angle=54.7; % [degrees] should be the same as assumed when calculating Z and RAT values, set to 0 for planar surface
% below needs to be set if generation.spectrum='monochromatic'
generation.monochromatic.wavelength=1200; % wavelength [nm] for monochromatic spectrum setting
generation.monochromatic.flux=1e15; % monochromatic photon flux [1/cm2/s]



%%%% external circuit settings
circuit.Rseries=0.4; % external series resistance [Ohm.cm2]
circuit.Rshunt=1e5; % external shunt resistance [Ohm.cm2]
circuit.terminal='light_IV_auto'; % 'Vuc', 'Vterm', 'Jterm', 'OC', 'MPP', 'Jsc' (not short circuit!), 'light_IV_auto', 'IV_curve', 'QE_curve', 'sunsVoc_curve' or 'Rs_curve'
circuit.Vuc.value=0.5; % unit vell voltage [V] for 'Vuc'
circuit.Vterm.value=0.5; % terminal voltage [V] for 'Vterm'
circuit.Jterm.value=-30; % terminal current density [mA/cm2] for 'Jterm'
circuit.IV.V_values=[0.2:0.05:0.75]; % vector of voltage values [V] for 'IV_curve'
circuit.IV.mode='Vterm'; % 'Vuc' (faster) or 'Vterm' defines the meaning of the voltage values for 'IV_curve'
circuit.QE.wavelength_values=[300:25:1125]; % vector of wavelength values [nm] for 'QE_curve'
circuit.sunsVoc.suns_values=10.^[-4:0.5:1];

% expert external circuit settings
circuit.DJ0=0; %  J0 [A/cm2] of external parallel diode in forward bias
circuit.Dn=2; % ideality factor of external parallel diode in forward bias
circuit.Voc_guess=0.67; % guess of Voc [V] for quicker convergence, can be a vector / matrix for sweeps
circuit.IV_accuracy=1; % use values >1 to increase the number of IV points calculated for 'light_IV_auto'; default: 1 (5 recommended for 'Rs_curve')



%%%% sweep
% sweep of one or two independent parameters
% additional parameters can be swept dependently:
% e.g. sweep_1{1}='size_x', sweep_1{2}='size_y' and values_1{1}= ...
sweep.enable=0; % 0 or 1 to disable / enable
sweep.param_1{1}='bulk.SRH.BO.Nt'; % parameter name in quotation marks, e.g. sweep_1='bulk.rho'
sweep.param_2{1}='circuit.Rseries'; % parameter name in quotation marks, e.g. sweep2='bulk.rho'
sweep.values_1{1}=[1e17 2e17 3e17]; % [] for no sweep or vector, e.g. [1 4 6]
sweep.values_2{1}=[]; % [] for no sweep or vector, e.g. [1 4 6]

