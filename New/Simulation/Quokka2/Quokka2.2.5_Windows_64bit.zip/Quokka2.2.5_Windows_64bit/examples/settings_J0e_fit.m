% Quokka v2.2 settings file
% (c) 2014 Andreas Fell

% Curve fitting example from PVSEC 2013
% Uses the optimizer to fit the J0e of a symmetrically diffused sample to a taueff(deltan) curve measured by QSSPC
% Thanks to Andy Thomson, ANU, for providing the data
% This is a simplified settings file; for a complete listing of available settings see settings_FRC_COMPLETE.m

version.design='FRC'; % don't change

%%%% unit cell geometry
geom.dimensions=1; % set to 1, 2 or 3
geom.Wz=345; % cell thickness [um] (including thickness of doped surface layers)
geom.meshquality=3; % determines solution accuracy and computation time, 1: coarse, 2: medium or 3: fine (or 'user' for expert settings)


                         
%%%% bulk material properties
bulk.type='n-type'; % doping type, 'p-type' or 'n-type'
bulk.rho=1; % resistivity [Ohm.cm]
bulk.taubfixed=1e20; % fixed lifetime [us] contribution to bulk recombination, set to very high value to disable
bulk.SRH.midgap.taup0=1e10; % taup (holes) for midgap SRH [us] (Et-Ei=0), set to very high value to disable
bulk.SRH.midgap.taun0=1e10; % taun (electrons) for midgap SRH [us] (Et-Ei=0), set to very high value to disable

% expert bulk settings
bulk.nieff='fixed'; % 'default' (uses ni(300K)=9.65e9cm-3 and Schenk's doping dependent BGN) or set value [cm-3]
bulk.nieffvalue=8.6e9; % this is the "Sinton" nieff for comparison


%%%% Boundary properties, conductive (e.g. surface diffusion) and non-conductive (e.g. undiffused passivated surface)

% Rear side
bound.conduct{1}.location='rear';
bound.conduct{1}.cont.rec='J0';
bound.conduct{1}.cont.J0=1800e-15;
bound.conduct{1}.cont.rc=1e-3;

% Front side
bound.conduct{2}.location='front';
bound.conduct{2}.cont.rec='J0';
bound.conduct{2}.cont.J0=1800e-15;
bound.conduct{2}.cont.rc=1e-3;



%%%% generation settings
generation.type='ext_file'; % how generation is defined:  '1D_model', 'Jgen_surface', 'Jgen_uniform', 'ext_file', 'customdata' or 'off'
generation.intensity=100; % incident light intensity [mW/cm2] (default: 100), not applicable for 1D_model, does NOT influence the actual generation
generation.ext_file='genprofile_Sinton_flash.xls'; % generation rate file; first column depth [um], second column G [cm-3s-1]
generation.suns=8; % scales the generation
generation.illum_side='front'; % illuminated side, 'front' or 'rear'



%%%% external circuit settings
circuit.Rseries=0.001; % external series resistance [Ohm.cm2]
circuit.Rshunt=1e5; % external shunt resistance [Ohm.cm2]
circuit.terminal='sunsVoc_curve'; % 'Vuc', 'Vterm', 'Jterm', 'OC', 'MPP', 'Jsc' (not short circuit!), 'light_IV_auto', 'IV_curve', 'QE_curve', 'sunsVoc_curve' or 'Rs_curve'
circuit.sunsVoc.suns_values=[2 4 8 12 16];


%%%% optimizer settings for data fitting or performance optimization
% when vector data are given identical optimization is performed sequentially for each value (all vectors must have the same length or be a scalar to be assumed constant)
optim.enable=2; % 0: disable, 1: normal mode, 2: curve fitting mode
optim.maxiter=20; % maximum number of iterations
optim.param{1}='bound.conduct{1}.cont.J0'; % parameter name to optimize (as given in settings file)
optim.start{1}=1300e-15; % (vector of) start value(s) of parameter (units as given in settings file)
optim.lb{1}=500e-15; % (vector of) lower bound(s)
optim.ub{1}=3000e-15; % (vector of) upper bound(s)

% goal settings for curve fitting mode (does not support sequential optimization)
optim.goalx='results.curves.navg'; % must be a vector result produced by a single simulation run
optim.goaly='results.curves.taueff'; % must be a vector result produced by a single simulation run with the same length as optim.goalx
optim.xyfile='QSSPC_lifetime_curve.xls'; % Excel file with two columns for x- and y-goal values, in units of optim.goalx and optim.goaly output scalars

% following settings provide possibility to override parameter values, useful for sequential optimization and parameter(s) dependent on the parameter(s) to optimize
% possible to define more overrides by cell index {2}, {3} ...
% to disable: optim.override.value{1}=[]
optim.override.param{1}='bound.conduct{2}.cont.J0'; % parameter name to override
optim.override.value{1}='bound.conduct{1}.cont.J0'; % (vector of) value(s) or analytic expression in quotation marks containing name(s) of parameter(s) to optimize