--[[
    Deep Learning (DL) Network Module for Lua
    To run this example:
    (i)     download the MNIST dataset from my website:
                * https://www.hamady.org/data/mnist/mnist_dataset.zip
            There are four files in the zip:
                * mnist_train_images.dat: 60000 MNIST images (size: 28*28*1)
                * mnist_train_labels.dat: 60000 corresponding labels
                * mnist_test_images.dat:  10000 MNIST images to test the trained model
                * mnist_test_labels.dat:  10000 corresponding labels
    (ii)    create a directory (such as ../test/) and two subdirectories ('../test/data/mnist' and '../test/model/mnist')
    (iii)   put the four files in the '../test/data/mnist' subdirectory
    (iv)    put the directory location name in the DLN_DIR string below
    (v)     play with model parameters and train it
]]

ldln = require("ldln")

print(ldln.version())

-- data location ----------------------------------------------------------
-- for Linux:
DLN_DIR = "../"
DATA_DIR = DLN_DIR .. "data/mnist/"
MODEL_DIR = DLN_DIR .. "model/mnist/"
-- for Windows:
-- DLN_DIR = ..\\"
-- DATA_DIR = DLN_DIR .. "data\\mnist\\"
-- MODEL_DIR = DLN_DIR .. "model\\mnist\\"

TRAIN_IMAGES_FILENAME = DATA_DIR .. "mnist_train_images.dat"
TRAIN_LABELS_FILENAME = DATA_DIR .. "mnist_train_labels.dat"
TEST_IMAGES_FILENAME  = DATA_DIR .. "mnist_test_images.dat"
TEST_LABELS_FILENAME  = DATA_DIR .. "mnist_test_labels.dat"

MODEL_FILENAME = MODEL_DIR .. "mnist.dlnmodel"
LOG_FILENAME = MODEL_DIR .. "mnist.log"
COST_FILENAME = MODEL_DIR .. "mnist_cost.txt"
---------------------------------------------------------------------------

-- model parameters -------------------------------------------------------
image_size_h = 28
image_size_w = 28
image_n_channel = 1
nnodes_input = image_size_h * image_size_w
nnodes_output = 10
nnodes_hidden = 512
n_train = 60000
n_validation = 10000
n_test = 10000
n_epoch = 2
criterion = ldln.CRITERION_CCE
validation = ldln.VALIDATION_ARGMAX
optimizer = ldln.OPTIMIZER_RMSPROP
early_stop = false
tolerance = 0.001
learning_rate = 0.001
n_batch = 20
n_thread = 5
patience = 1
n_kernel = 32
kernel_size = 3
activation = ldln.ACTIVATION_RELU
dropout = 0
padding = 1
stride = 2
---------------------------------------------------------------------------

nTic = ldln.milliseconds()

-- create the DL model
dln = ldln.create("mnist", criterion, validation, optimizer, early_stop, tolerance)
-- add a convolution layer (will be the input layer) with the ReLu activation and no dropout
layer = ldln.add_layer_conv(dln, image_size_h, image_size_w, image_n_channel, n_kernel, kernel_size, activation, dropout, "conv", padding, stride)
-- add a fully connected layer (perceptron): its input is the previous layer output
nnodes_hidden = ldln.get_layer_output_size(layer)
ldln.add_layer(dln, nnodes_hidden, ldln.ACTIVATION_NONE, 0, "hidden");
-- add the output layer with SoftMax activation
ldln.add_layer(dln, nnodes_output, ldln.ACTIVATION_SOFTMAX, 0, "output");
-- set the log file (outputs will be written in this file)
ldln.set_log(dln, LOG_FILENAME, false)
-- compile the model
ldln.compile(dln)
-- print out the model summary
ldln.summary(dln)
-- initialize the train structure
ldln.init_train(dln, n_train, n_validation, nnodes_input, nnodes_output)
-- load the training data
print("\nreading train dataset...")
ldln.mnist_load_train(dln, TRAIN_IMAGES_FILENAME, TRAIN_LABELS_FILENAME)
-- train the model
print("\nmodel training...")
ldln.train(dln, n_batch, n_thread, n_epoch, learning_rate, patience)
-- save the model
print("\nsaving model...")
ldln.save(dln, MODEL_FILENAME, true)
-- print out the total duration
ldln.print_duration("DL network training/saving duration: ", ldln.milliseconds() - nTic, 'L');
-- initialize the test structure
ldln.init_test(dln, n_test, nnodes_input, nnodes_output)
-- load the test data
print("\nreading test dataset...")
ldln.mnist_load_test(dln, TEST_IMAGES_FILENAME, TEST_LABELS_FILENAME)
-- run the test and calculate the model accuracy
print("\npredicting...")
cost_test = 0
n_correct = 0
argm_num_s = {}
argm_num_f = {}
for i = 1, 10 do
    argm_num_s[i] = 0
    argm_num_f[i] = 0
end
for n = 1, n_test do
    loss_test = ldln.predict(dln, n)
    cost_test = cost_test + loss_test
    tsr_output = ldln.get_output(dln)
    tsr_target = ldln.get_test_target(dln, n)
    argm_z = ldln.argmax(tsr_output)
    argm_t = ldln.argmax(tsr_target)
    if (argm_t == argm_z) then
        n_correct = n_correct + 1
    end
end
best_epoch = ldln.get_best_epoch(dln)
cost_train = ldln.get_cost_train(dln, best_epoch)
cost_validation = ldln.get_cost_validation(dln, best_epoch)
accuracy = ldln.get_accuracy(dln, best_epoch)
cost_test = cost_test / n_test
print("\nresult summary:");
print(string.format("dataset size: train images: %d; validation images: %d; test images: %d", n_train, n_validation, n_test))
print(string.format("test cost: %12.8f (validation cost: %12.8f); test accuracy: %5.2f %% (validation accuracy: %5.2f %%)\n",
    cost_test, cost_validation, (100.0 * n_correct) / n_test, 100.0 * accuracy))

-- run the test and calculate the model accuracy
ldln.save_cost(dln, COST_FILENAME);

ldln.destroy(dln)
