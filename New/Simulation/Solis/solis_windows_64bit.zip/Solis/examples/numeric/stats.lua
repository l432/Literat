--[[
    Solis example
    Descriptive Statistics
]]

t = {1,1,2,3,4,4,5}
-- expected: m = 2.8571428571429
m = stats.mean(t)
cls()
print(m)
