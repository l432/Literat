-- Library for Arbitrary Precision Math (MAPM) by Michael C. Ring
-- Lua interface by Luiz Henrique de Figueiredo

lmapm = require ("lmapm")

-- lmapm library functions:
--  __add(x,y)      cbrt(x)          mod(x,y) 
--  __div(x,y)      ceil(x)          mul(x,y) 
--  __eq(x,y)       compare(x,y)     neg(x) 
--  __lt(x,y)       cos(x)           number(x) 
--  __mod(x,y)      cosh(x)          pow(x,y) 
--  __mul(x,y)      digits([n])      round(x) 
--  __pow(x,y)      digitsin(x)      sign(x) 
--  __sub(x,y)      div(x,y)         sin(x) 
--  __tostring(x)   exp(x)           sincos(x) 
--  __unm(x)        exponent(x)      sinh(x) 
--  abs(x)          factorial(x)     sqrt(x) 
--  acos(x)         floor(x)         sub(x,y) 
--  acosh(x)        idiv(x,y)        tan(x) 
--  add(x,y)        inv(x)           tanh(x) 
--  asin(x)         iseven(x)        tonumber(x) 
--  asinh(x)        isint(x)         tostring(x,[n,exp]) 
--  atan(x)         isodd(x)         version
--  atan2(y,x)      log(x) 
--  atanh(x)        log10(x) 

print("\nSquare root of 2")

lmapm.digits(65)
function mysqrt(x)
    local y,z=x,x
    repeat
        z,y=y,(y+x/y)/2
    until z==y
    return y
end

print("math.sqrt(2)           ", math.sqrt(2))
print("mysqrt(2)              ", mysqrt(2))
a = lmapm.sqrt(2)
print("lmapm.sqrt             ", a)
b = mysqrt(lmapm.number(2))
print("mysqrt(lmapm.number(2))", b)
R = lmapm.number("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327641573")
print("exact ", R)
print(a==b, a<b, a>b, lmapm.compare(a,b))

print ("\nFactorials")

function factorial(n,f)
    for i=2,n do
        f=f*i
    end
    return f
end

one=lmapm.number(1)
for i=1,30 do
    io.write(i, "  \t", lmapm.tostring(factorial(i,one),0), "\n")
end

print(lmapm.version)
