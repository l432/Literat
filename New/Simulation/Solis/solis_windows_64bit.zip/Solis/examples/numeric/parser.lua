--[[
    Solis example
    Math Parser
]]

cls()
p = parser.new()
parser.set(p, "x", 1)
parser.set(p, "a", 2)
y = parser.eval(p, "a*x + sin(x/a) + 2")
res = string.format("y = %g\n", y)
print(res)
