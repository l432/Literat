--[[
    Solis example
    FFT
]]

Fo = 1            -- signal frequency (Hz)
To = 1/Fo         -- signal period (seconds)
A = 5             -- signal amplitude
An = 1            -- noise amplitude
N = 256           -- number of points (power of 2)
Ts = 4 * To/N     -- sampling period
Fs = 1/Ts         -- sampling frequency
f = {}
t = {}
y = {}

for i = 1, N, 1 do
    f[i] = (i - 1) * Fs / (N - 1)  -- frequency
    t[i] = (i - 1) * Ts            -- time
    y[i] = A*cos(2*pi*Fo*t[i]) + An*lmath.random()
end

tfd = data.fft(y, 1)

p = plot.new()
plot.set(p, "title", "FFT")
plot.add(p, f, tfd)               -- plot FTT versus frequency
plot.update(p)
