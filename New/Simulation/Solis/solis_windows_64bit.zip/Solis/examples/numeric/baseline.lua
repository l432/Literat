--[[
    Solis test
    Baseline correction using the algorithm in Zhang et al., Analyst, 135(5), 1138-1146.
]]

cls()

fname = "data.txt"
datax, datay = data.load(fname, "\t")
datayc, status = data.baseline(datay, 50, 100, 1e-3)
if status then
    print("baseline correction succeeds")
end
datay = data.normalize(datay, 100)
datayc = data.normalize(datayc, 100)
fname = "data_corrected.txt"
data.save(fname, "\t", "# baseline-corrected data", datax, datayc)

p = plot.new()
plot.add(p, datax, datay)
plot.add(p, datax, datayc)
plot.update(p)
