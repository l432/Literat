--[[
    Solis example
    Data Fitting
]]

cls()

function func(fpar, dpar, x)
   dpar[1] = 1
   dpar[2] = x
   y = fpar[1] + fpar[2] * x
   return y
end

tx = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
ty = {0.1, 0.8, 2.2, 3.1, 3.8, 5.1, 5.9, 7.1, 8.0, 9.2}
fpar = {3,3}
ipar = {1,1}
pars, chi, iters = data.fit("func", tx, ty, fpar, ipar, 1e-3, 100)

io.write(string.format("pars = [%g %g]\nchi = %g, iters = %d\n", pars[1], pars[2], chi, iters))

p = plot.new(800,600)
plot.set(p, "title", "Linear Fitting")
txf = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
tyf = {}
for i = 1, #txf, 1 do
   tyf[i] = pars[1] + pars[2]*txf[i]
end
plot.add(p, txf, tyf)      -- plot linear fit
plot.add(p, tx, ty)        -- plot data
plot.set(p, 1, "color", "red")
plot.set(p, 2, "style", "o")
plot.update(p)