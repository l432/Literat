--[[
    Solis example
    Math functions
]]

cls()
res = string.format("cos(pi/4) = %g\n", cos(pi/4))
io.write(res)
