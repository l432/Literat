--[[
    Solis example
    Minimization of a function
]]

function booth(x) 
    return (math.pow(x[1] + 2*x[2] - 4, 2) + math.pow(2*x[1] + x[2] - 5, 2))
end

x = { -5, 5 }
iters = optim.minimize("booth", x, 100, 1e-7)
-- expected: x = {2,  1}
res = string.format("\n x = [%g %g]  iters = %d\n", x[1], x[2], iters)

cls()
io.write(res)