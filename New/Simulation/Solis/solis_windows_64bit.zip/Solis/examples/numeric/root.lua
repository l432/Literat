--[[
    Solis example
    Zero of a function
]]

cls()

function func(x) 
    return x^2 - x - 1
end

-- expected: x ~ -0.618034
x = optim.root("func", -2, 2)
res = string.format("x = %g   f(x) = %g\n", x, func(x))
io.write(res)
