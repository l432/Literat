--[[
    Solis example
    Ordinary Differential Equation
]]

-- Damped Oscillator: y'' + c y' + k y = 0

local c = 0.5
local k = 1
function func(t, y, ydot)
    ydot[1] = y[2]
    ydot[2] = (-c * y[2]) + (-k * y[1])
end

-- Solve with 0.1 seconds as interval
y0 = {2, 0}
t0 = 0
dt = 0.1
t1 = t0 + dt
tol = 1e-3
tm = {}
y = {}
dy = {}

for i = 1,100,1 do
    yy = ode.solve("func", y0, t0, t1, tol)
    tm[i] = t1
    y[i] = yy[1]
    dy[i] = yy[2]
    t0 = t1
    t1 = t1 + dt
    y0[1] = yy[1]
    y0[2] = yy[2]
end

-- plot solution, y and y'
p = plot.new()
plot.set(p, "title", "Ordinary Differential Equation")
plot.add(p, tm, y)
plot.add(p, tm, dy)
plot.set(p, "xlabel", "time(s)")
plot.set(p, "ylabel", "amplitude")
plot.set(p, 1, "legend", "y(t)")
plot.set(p, 1, "style", "-")
plot.set(p, 1, "color", "red")
plot.set(p, 2, "legend", "y'(t)")
plot.set(p, 2, "style", "-")
plot.set(p, 2, "color", "blue")
plot.update(p)