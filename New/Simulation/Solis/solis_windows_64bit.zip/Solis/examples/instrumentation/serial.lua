--[[
    Solis example
    Serial Communication C Module
]]

cls()

-- load the serial communication C module
local rs = require("lserial")

-- print out info about the serial communication C module release
print(rs.version())

-- open the serial port and configure it
-- port_handle = rs.open(port_num, settings, verbose)
--     port_num: usually 1 (COM1) or 2 (COM2)
--     settings syntax: "[baud=b][parity=p][data=d][stop=s][to={on|off}][xon={on|off}][odsr={on|off}][octs={on|off}][dtr={on|off|hs}][rts={on|off|hs|tg}][idsr={on|off}]"
--         settings has the same meaning than in the Windows BuildCommDCB function ( https://msdn.microsoft.com/fr-fr/library/windows/desktop/aa363143%28v=vs.85%29.aspx ),
--            except that BuildCommDCB has no 'timeout' parameter that is specific to this Solis module
--     verbose (optional): true to show detailed messages (for debugging purpose, not in production to avoid too much verbosity)
-- returns the port handle
p = rs.open(1, "baud=9600 parity=n data=8 stop=1 timeout=1000", true)

-- write to the serial port
-- rs.write(port_handle, command)
--     port_handle: the port handle, as returned by rs.open
--     command to send to the device
-- returns the number of bytes written
rs.write(p, "*IDN?")

-- read from the serial port
-- r,n = rs.read(port_handle, bytes)
--     port_handle: the port handle, as returned by rs.open
--     bytes: number of bytes to read
-- returns the string read and the number of bytes read
r,n = rs.read(p, 128)
io.write("\n recv = ", r, " ; bytes read = ", n)

-- close the serial port
-- rs.close(port_handle)
--     port_handle: the port handle, as returned by rs.open
rs.close(p)
