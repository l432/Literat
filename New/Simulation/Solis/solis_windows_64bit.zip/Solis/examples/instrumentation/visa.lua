--[[
    Solis example
    VISA C Module for Solis
    for Windows only
]]

cls()

local vi = require("lvisa")             -- load visa module
print(vi.version())                     -- print version

v = vi.open("GPIB::8::INSTR")           -- open visa connection
print(vi.status())                      -- print status

vi.write(v, "*IDN?")                    -- send command to device
time.sleep(50)                          -- sleep during 50 ms
r = vi.read(v,100)                      -- read the device response
print(r)                                -- print it

vi.close(v)                             -- close visa connection
print(vi.status())                      -- print status
