--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_mobility(position, thickness, temperature, concentration)

    mun = 1000     -- electron mobility in cm2/Vs
    mup = 500      -- hole mobility in cm2/Vs

    graded = false
    status = true

    return mun, mup, graded, status
end
