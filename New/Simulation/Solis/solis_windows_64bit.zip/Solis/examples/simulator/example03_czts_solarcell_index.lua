--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_index(position, thickness, bandgap, lambda)

    Eph = 1.23984 / lambda
    Eg  = bandgap
    kA  = 0.2
    graded = false

    n = 2.59

    if (Eph >= Eg) then
        k = (2.0 * Eg / Eph) * kA * sqrt((Eph - Eg) / Eg)
    else
        k = 0.0
    end

    -- the last two parameters (boolean graded and status) are optional
    graded = false
    status = true

    return n, k
end
