--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_permittivity(position, thickness, temperature)

    eps = 11.8     -- relative permittivity
    graded = false

    --
    --

    graded = false
    status = true

    return eps, graded, status
end
