--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_index(position, thickness, bandgap, lambda)
    Eph = 1.23984 / lambda
    Eg = 1.12
    kA = 0.05
    graded = false

    n = 3.42    -- refractive index
    k = 0.0     -- extinction coefficient
    if (Eph >= Eg) then
        k = (kA * ((Eph - Eg) / Eg) * ((Eph - Eg) / Eg))
    end

    return n, k, graded, true
end