--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_recombination(position, thickness)

    Beta = 1.1e-14        -- Radiative recombination coefficient (cm3/s)
    Cn = 8.3e-32          -- Auger recombination constant for electrons (cm6/s)
    Cp = 1.8e-31          -- Auger recombination constant for holes (cm6/s)
    Taun = 1e-7           -- Electron lifetime (seconds)
    Taup = 1e-7           -- Hole lifetime (seconds)

    --
    --

    graded = false
    status = true

    return Beta, Cn, Cp, Taun, Taup, graded, status
end
