--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_index(position, thickness, bandgap, lambda)

    n = 1.3
    k = 1.0

    graded = false
    status = true

    return n, k, graded, status
end
