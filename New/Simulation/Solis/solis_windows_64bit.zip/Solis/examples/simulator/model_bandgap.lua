--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_bandgap(position, thickness, temperature, concentration)

    eg = 1.12     -- bandgap (eV)
    chi = 4.17    -- affinity (eV)
    nc = 2.8e19   -- density of states in conduction band in 1/cm3
    nv = 1.04e19  -- density of states in valence band in 1/cm3

    --
    --

    graded = false
    status = true

    return eg, chi, nc, nv, graded, status
end
