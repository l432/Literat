--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_index(position, thickness, bandgap, lambda)

    Eph = 1.23984 / lambda
    Eg  = bandgap
    kA  = 0.05

    n = 3.42

    if (Eph >= Eg) then
        k = (2.0 * Eg / Eph) * (kA * ((Eph - Eg) / Eg) * ((Eph - Eg) / Eg))
    else
        k = 0.0;
    end

    graded = false
    status = true

    return n, k, graded, status
end

