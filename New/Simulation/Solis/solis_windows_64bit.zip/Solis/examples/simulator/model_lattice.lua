--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_lattice(position, thickness)

    a = 0.4                 -- Lattice a parameter (nm)
    e31 = 0                 -- Piezoelectric parameter (C/m2)
    e33 = 0                 -- Piezoelectric parameter (C/m2)
    c13 = 100               -- Elastic parameter (GPa)
    c33 = 400               -- Elastic parameter (GPa)
    Psp = 0                 -- Spontaneous polarization (C/m2)

    graded = false
    status = true

    return a, e31, e33, c13, c33, Psp, graded, status
end