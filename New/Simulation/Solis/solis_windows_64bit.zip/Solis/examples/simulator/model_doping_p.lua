--------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_doping(position, thickness)

    Na = 1e15       -- acceptor density (1/cm3)
    Nd = 0          -- donor density (1/cm3)
    Nr = 1e21       -- reference density (1/cm3)
    Taun = 1e-7     -- electron lifetime (seconds)
    Taup = 1e-7     -- hole lifetime (seconds)
    E = 0           -- activation energy (eV)
    F = 1           -- degeneracy factor

    --
    --

    graded = false
    status = true

    return Na, Nd, Nr, Taun, Taup, E, F, graded, status
end
