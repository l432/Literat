 --------------------------------------------------------------
-- Solis Lua Model
-- Solis <Version 3.0 Build 2411>
--------------------------------------------------------------

function sol_doping(position, thickness)
    Na = 1e15           -- background acceptor density in 1/cm3
    N0 = 1e20           -- donor density at the layer surface in 1/cm3
    Nr = 1e19           -- reference density in 1/cm3
    Taun = 1e-4         -- electron lifetime (seconds)
    Taup = 1e-4         -- hole lifetime (seconds)
    E = 0               -- activation energy (eV)
    F = 1               -- degeneracy factor
    graded = true       -- set graded to true in this case

    posr = 0.2
    Nd = N0 * math.exp(-(position * position) / (posr * posr))

    return Na, Nd, Nr, Taun, Taup, E, F, graded, true
end