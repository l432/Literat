-- https://www.tecgraf.puc-rio.br/iup/en/basic/index.html

require "iuplua"

counter = 0
text = iup.text{readonly = "YES", value = "", expand = "YES", alignment = "ACENTER"}
button = iup.button{title = "Stop", expand = "YES"}

function idle_cb()
    counter = counter + 1
    text.value = string.format("Iteration %d", counter)
    if counter == 10000 then
        iup.SetIdle(nil)
        button.title = "Start"
    end
    return iup.DEFAULT
end

function button:action()
    text.value = ""
    counter = 0
    iup.SetIdle(nil)
    if button.title == "Stop" then
        button.title = "Start"
    else
        iup.SetIdle(idle_cb)
        button.title = "Stop"
    end
end

dlg = iup.dialog
{
    iup.vbox
    {
        iup.hbox
        {
            button;
            margin = "20x20",
            alignment = "ACENTER"
        };
        iup.hbox
        {
            text;
            margin = "20x20",
            alignment = "ACENTER"
        };
    },
    title = "IUP",
    size = "160x80",
    icon = 0,
}

dlg:showxy(iup.CENTER, iup.CENTER)
iup.SetIdle(idle_cb)
if (iup.MainLoopLevel() == 0) then
    iup.MainLoop()
end

iup.Close()