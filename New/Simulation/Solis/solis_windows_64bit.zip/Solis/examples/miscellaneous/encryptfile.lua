--[[
    Solis example
    AES encryption
]]

lcrypt = require("lcrypt")

function bytestostr(t)
    local str = ''
    for _,v in pairs(t) do
        str = str .. string.char(v)
    end
    return str
end

local fname = 'encryptfile.lua'
local pf = assert(io.open(fname, 'rb'))
local inp = {}
repeat
    local bt = pf:read(4096)
    for ct in (bt or ''):gmatch'.' do
        inp[#inp+1] = ct:byte()
    end
until not bt
pf:close()

-- AES key (16 bytes = 128 bits)
key = { 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C }

-- encrypt the file
outp = lcrypt.encrypt(inp, key)
local fnameEncrypted = 'encryptedfile.lua'
pf = assert(io.open(fnameEncrypted, 'wb'))
pf:write(bytestostr(outp))
pf:close()

-- decrypt the file
inp_decrypted = lcrypt.decrypt(outp, key)
local fnameDecrypted = 'decryptedfile.lua'
pf = assert(io.open(fnameDecrypted, 'wb'))
pf:write(bytestostr(inp_decrypted))
pf:close()
