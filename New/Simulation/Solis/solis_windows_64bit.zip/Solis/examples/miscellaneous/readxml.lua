--[[
    Solis example
    XML
]]

lxml = require ("lxml")
filename = "input.xml"
fp = io.open(filename, "r")
xmlcontent = fp:read("*all")
xmlvalue = lxml.read(xmlcontent, "solis", "device")
print("XML value of solis/device = " .. xmlvalue)
print(lxml.version())
