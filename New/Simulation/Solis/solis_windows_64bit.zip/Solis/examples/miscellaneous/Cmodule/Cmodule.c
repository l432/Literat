/*
    Solis example
    C Module
*/

/*
    HowTo write and use C module:
    Step 1. Write your C module and register the interface functions as in this example.
    Step 2. Build your C module with your favorite C compiler:
                Visual C++ on Windows or gcc or Clang on Linux, for example. Before compiling, add the Solis include directory (Solis Dir/include) in the compiler include
                    path and set the linker to link against the Solis Lua Core library (libluacore.dll under Windows and
                    libluacore.so under Linux). Under Visual C++, you can generate, for your specific VC version, the lib from libluacore.dll and
                    libluacore.def by using the lib tool included in Visual C++ as follows:
                        cd C:\Solis\bin\
                        dumpbin /exports libluacore.dll > ..\lib\libluacore.def
                        cd ..\lib\
                        lib /def:"libluacore.def" /out:"libluacore.lib" /machine:x64
                Under Linux, you can use a Makefile such as the one located in Solis/examples/miscellaneous/Cmodule
                Of course, if your module is already built or purchased you can use it as usual with the Lua ad hoc functions.
    Step 3. When your module was built as dll (under Windows) or so (under Linux), you can load it and use it
                under Solis by using the standard Lua functions:
                    -- Load C module, the Lua standard way
                    cls()
                    local Cmodule = require("Cmodule")
                    print(Cmodule.version())
*/

/* put the Solis include dir in your include path */
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

static void register_module_cfunctions(lua_State *L, const char *modulename, const luaL_Reg *funcs)
{
#if LUA_VERSION_NUM < 502
    luaL_register(L, modulename, funcs);
#else
    iuplua_get_env(L);
    if (lua_istable(L, -1))
        luaL_setfuncs(L, funcs, 0);
    else {
        if (!lua_isnil(L, -1))
            luaL_error(L, "name conflict for module \"%s\"", modulename);

        luaL_newlib(L, funcs);
        lua_pushvalue(L, -1);
        lua_setglobal(L, modulename);
    }
#endif
}

#ifdef WIN32
#define CMODULE_API __declspec(dllexport)
#else
#define CMODULE_API
#endif

static int Cmodule_version(lua_State *pLua)
{
    lua_pushstring(pLua, "Cmodule v0.1");
    return 1;
}

static const luaL_Reg Cmodule[] = {
    { "version", Cmodule_version },
    { NULL, NULL }
};

CMODULE_API int luaopen_Cmodule(lua_State *pLua)
{
    register_module_cfunctions(pLua, "Cmodule", Cmodule);
    return 1;
}
