--[[
    Solis example
    SQL
]]

lsql = require ("lsql")

dbfilename = "database.sqlite"
db = lsql.create(dbfilename)            -- create the database
sql = "DROP TABLE IF EXISTS TABLE_HEADER; CREATE TABLE TABLE_HEADER(Id INTEGER, Name TEXT, Description TEXT);"
qy = lsql.exec(db, sql)                 -- exec a statement
sql = "INSERT INTO TABLE_HEADER VALUES(1, 'first', 'first description')"
qy = lsql.exec(db, sql)
sql = "INSERT INTO TABLE_HEADER VALUES(2, 'second', 'second description')"
qy = lsql.exec(db, sql)

qy = lsql.query(db, "SELECT * FROM 'TABLE_HEADER' LIMIT 0,2")
lsql.next(db, qy)                       -- go to the first row
id = lsql.read(db, qy, 1)               -- read column #1
name = lsql.read(db, qy, 2)             -- read column #2
description = lsql.read(db, qy, 3)      -- read column #3
print("\n", id, name, description)
lsql.next(db, qy)                       -- go to the next row
id = lsql.read(db, qy, 1)               -- read column #1
name = lsql.read(db, qy, 2)             -- read column #2
description = lsql.read(db, qy, 3)      -- read column #3
print("\n", id, name, description)
lsql.close(db)                          -- close the database

print(lsql.version())
