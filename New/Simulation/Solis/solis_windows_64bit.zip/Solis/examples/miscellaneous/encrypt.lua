--[[
    Solis example
    AES encryption
]]

lcrypt = require("lcrypt")

function printbytes(t)
    local str = '{ 0x'
    for _,v in pairs(t) do
        str = str .. string.format('%02X', v)
    end
    str = str .. ' }'
    print(str, "\n")
end

cls()

-- array of bytes
inp = { 0x6B, 0xC1, 0xBE, 0xE2, 0x2E, 0x40, 0x9F, 0x96, 0xE9, 0x3D, 0x7E, 0x11, 0x73, 0x93, 0x17, 0x2A }
print("Input:\n")
printbytes(inp)

-- AES key (16 bytes = 128 bits)
key = { 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C }
print("Key:\n")
printbytes(key)

-- encrypt the array of bytes
outp = lcrypt.encrypt(inp, key)

-- decrypt the array of bytes and compare to the initial data table
inp_decrypted = lcrypt.decrypt(outp, key)
print("Decrypted:\n")
printbytes(inp_decrypted)
