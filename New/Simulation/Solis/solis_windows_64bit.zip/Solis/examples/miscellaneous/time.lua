--[[
    Solis example
    Timing
]]

time.tic()
time.sleep(1000)
dt = time.toc()            -- time (in milliseconds) elapsed since the tic call
cls()
print(time.format(dt))
