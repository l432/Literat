--[[
    Solis example
    Plot
]]

x = {0,1,2,3,4,5}
y = {0,1,2,3,4,5}
p = plot.new(800,600)           -- create a plot
plot.add(p, x, y)               -- add curve to the new plot
plot.set(p, 1, "size", 2)       -- set curve #1 line size
plot.set(p, 1, "style", "-o")   -- set curve #1 style (line and marker)
plot.update(p)
